<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }

    public function ebod(): string
    {
        return view('ebod');
    }

    public function encio()
    {
        return view('encio');
    }

    public function dona(): string
    {
        return view('dona');
    }
}
