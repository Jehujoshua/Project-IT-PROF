<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index', ['as' => 'home']);
$routes->get('ebod', 'Home::ebod', ['as' => 'ebod']);
$routes->get('encio', 'Home::encio', ['as' => 'encio']);
$routes->get('dona', 'Home::dona', ['as' => 'dona']);