﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="<?= base_url('bloglogo.png') ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>

<style>
:root{
    --paper:#faf9f7;
    --line:rgba(0,0,0,.1);
    --text:#1a1a1a;
    --muted:#6b6b6b;
}

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    background:var(--paper);
    color:var(--text);
    font-family:Arial,Helvetica,sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

.page{
    width:100%;
    max-width:1200px;
    margin:0 auto;
    padding:0 16px 60px;
}

img{max-width:100%}

/* ---------- HEADER ---------- */

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:24px 0;
    border-bottom:1px solid var(--line);
}

.brand{
    font-family:Times,serif;
    font-size:1.5rem;
    font-weight:700;
    letter-spacing:-.02em;
}

.nav{
    display:flex;
    gap:28px;
    font-size:.75rem;
    text-transform:uppercase;
    letter-spacing:.12em;
    color:var(--muted);
}

.nav a{
    transition:.2s;
}

.nav a:hover{
    color: black;
}

/* ---------- HERO ---------- */

.hero{
    margin-top:40px;
}

.hero img{
    width:100%;
    height:auto;
    max-height:900px;
    object-fit:contain;
    display:block;
}



/* ---------- TITLE ---------- */

h1{
    font-family:Times,serif;
    font-size:clamp(2.2rem,5vw,3.4rem);
    margin:45px 0 12px;
    letter-spacing:-.02em;
}

.lede{
    max-width:auto;
    color:var(--muted);
    line-height:1.8;
    font-size:1rem;
}

/* ---------- MAIN CONTENT ---------- */

.split{
    display:block;
    margin-top:32px;
}

/* ---------- CARDS ---------- */

.cards{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:20px;
    align-items:stretch;
}

.card{
    background:#fff;
    border:1px solid var(--line);
    padding:24px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    gap:16px;
    min-height:240px;
    transition:.2s;
}

.card:hover{
    transform:translateY(-3px);
}

.card h3{
    font-family:Times,serif;
    margin:0 0 4px;
    font-size:1.3rem;
    line-height:1.2;
}

.card-sub{
    margin:0 0 10px;
    font-size:.78rem;
    color:var(--muted);
}

.card p{
    color:var(--muted);
    line-height:1.7;
    margin:0 0 22px;
    font-size:.92rem;
}

.card a{
    font-size:.74rem;
    text-transform:uppercase;
    letter-spacing:.1em;
    border-bottom:1px solid var(--text);
    width:fit-content;
    padding-bottom:3px;
}

/* ---------- SIDEBAR ---------- */

.side{
    background:#fff;
    border:1px solid var(--line);
}

.side img{
    width:100%;
    height:auto;
    max-height:320px;
    object-fit:contain;
    background:#fff;
    display:block;
}

.side div{
    padding:18px;
    color:var(--muted);
    line-height:1.7;
    font-size:.86rem;
}

/* ---------- FOOTER ---------- */

footer{
    margin-top:60px;
    padding-top:20px;
    border-top:1px solid var(--line);
    display:flex;
    justify-content:space-between;
    color:var(--muted);
    font-size:.75rem;
}

/* ---------- RESPONSIVE ---------- */

@media(max-width:1100px){
    .page{
        max-width:960px;
    }

    .hero img{
        max-height:380px;
    }
}

@media(max-width:900px){

    .cards{
        grid-template-columns:1fr;
    }

    .split{
        grid-template-columns:1fr;
    }

    .side{
        max-width:420px;
    }
}

@media(max-width:760px){

    .page{
        padding:0 16px 40px;
    }

    .nav{
        display:none;
    }

    .hero img{
        max-height:300px;
    }

    h1{
        margin-top:30px;
    }

}
</style>
</head>

<body>

<div class="page">

<header class="topbar">
    <div class="brand">Big 3</div>

    <nav class="nav">
        <a href="<?= site_url('/') ?>">Home</a>
        <a href="<?= site_url('ebod') ?>">Ebod</a>
        <a href="<?= site_url('encio') ?>">Encio</a>
        <a href="<?= site_url('dona') ?>">Jehu</a>
    </nav>
</header>

<section class="hero">
    <img src="<?= base_url('homehero.png') ?>" alt="project hero">
</section>

<h1>Three people, Three builds, One mind.</h1>

<p class="lede">
    Each of us built a project from scratch. We each had the same requirements, but we each had different ideas and approaches. The result is three unique projects that showcase our individual skills and creativity.
</p>

<div class="split">

    <div class="cards">

        <article class="card">
            <div>
                <h3>Joshua Ebod</h3>
                <p class="card-sub">The IT Guy</p>
                <p>
                    Builds the website, writes the code, manages the database, and ensures everything works smoothly.
                </p>
            </div>

            <a href="<?= site_url('ebod') ?>">
                Open →
            </a>
        </article>

        <article class="card">
            <div>
                <h3>Andi Cris Encio</h3>
                <p class="card-sub">The Big Guy</p>
                <p>
                    Every meal is a step toward a stronger version of yourself.
                </p>
            </div>

            <a href="<?= site_url('encio') ?>">
                Open →
            </a>
        </article>

        <article class="card">
            <div>
                <h3>Jehu Joshua Besanes</h3>
                <p class="card-sub">The Creator Guy</p>
                <p>
                    The creative mind behind the project, turning ideas into reality through planning, innovation, and teamwork.
                </p>
            </div>

            <a href="<?= site_url('dona') ?>">
                Open →
            </a>
        </article>
    </div>

    </div>
        <footer>
            <span>© 2026 Project Lab</span>
        </footer>
    </div>

</body>
</html>