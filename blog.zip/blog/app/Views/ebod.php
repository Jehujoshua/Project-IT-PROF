<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="<?= base_url('bloglogo.png') ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ebod</title>

<style>
:root{
    --paper:#fbfbfa;
    --line:rgba(0,0,0,.1);
    --text:#161616;
    --muted:#6f6f6f;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:var(--paper);
    color:var(--text);
    font-family:Arial,Helvetica,sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

img{
    max-width:100%;
    display:block;
}

.page{
    max-width:1200px;
    margin:0 auto;
    padding:0 30px 70px;
}

/* ---------- HEADER ---------- */

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:24px 0;
    border-bottom:1px solid var(--line);
}

.brand{
    font-family:Georgia,serif;
    font-size:1.4rem;
    font-weight:700;
}

.nav{
    display:flex;
    gap:28px;
    font-size:.75rem;
    text-transform:uppercase;
    letter-spacing:.12em;
    color:var(--muted);
}

.nav a{
    transition:.2s;
}

.nav a[href*="ebod"]{
    color:var(--text);
    border-bottom:1px solid var(--text);
}

.nav a:hover{
    color:var(--text);
}

/* ---------- PERSON ---------- */

.person{
    display:grid;
    grid-template-columns:1fr 400px;
    gap:50px;
    align-items:center;
    margin-top:50px;
}

.kicker{
    font-size:.72rem;
    text-transform:uppercase;
    letter-spacing:.16em;
    color:var(--muted);
    margin-bottom:12px;
}

h1{
    font-family:Georgia,serif;
    font-size:clamp(2.3rem,5vw,3.4rem);
    margin-bottom:20px;
    letter-spacing:-.02em;
}

.about{
    max-width:650px;
    color:var(--muted);
    line-height:1.9;
    font-size:1rem;
}

/* ---------- HERO ---------- */

.hero{
    background:#fff;
    border:1px solid var(--line);
}

.hero img{
    width:100%;
    height:480px;
    object-fit:cover;
}

.hero div{
    padding:16px 18px;
    border-top:1px solid var(--line);
    color:var(--muted);
    font-size:.84rem;
}

/* ---------- PROJECT ---------- */

.project{
    margin-top:60px;
    background:#fff;
    border:1px solid var(--line);
}

.project img{
    width:100%;
    height:500px;
    object-fit:cover;
}

.project-body{
    padding:30px;
}

.project-body h2{
    font-family:Georgia,serif;
    font-size:2rem;
    margin:10px 0 16px;
}

.project-body p{
    color:var(--muted);
    line-height:1.9;
    font-size:1rem;
    max-width:800px;
}

/* ---------- FOOTER ---------- */

footer{
    margin-top:60px;
    padding-top:20px;
    border-top:1px solid var(--line);
    display:flex;
    justify-content:space-between;
    color:var(--muted);
    font-size:.75rem;
}

/* ---------- RESPONSIVE ---------- */

@media(max-width:900px){

    .person{
        grid-template-columns:1fr;
        gap:30px;
    }

    .hero{
        max-width:450px;
    }

    .project img{
        height:320px;
    }

}

@media(max-width:768px){

    .page{
        padding:0 20px 40px;
    }

    .nav{
        display:none;
    }

    .topbar{
        padding:18px 0;
    }

    .person{
        margin-top:35px;
    }

    h1{
        margin-bottom:16px;
    }

    .hero img{
        height:350px;
    }

    .project{
        margin-top:40px;
    }

    .project-body{
        padding:22px;
    }

    .project-body h2{
        font-size:1.6rem;
    }

    footer{
        margin-top:40px;
    }

}
</style>
</head>

<body>

    <div class="page">
        <header class="topbar">
            <div class="brand">
                Ebod
            </div>
            <nav class="nav">
                <a href="<?= site_url('/') ?>">Home</a>
                <a href="<?= site_url('ebod') ?>">Ebod</a>
                <a href="<?= site_url('encio') ?>">Encio</a>
                <a href="<?= site_url('dona') ?>">Jehu</a>
            </nav>
        </header>

    <section class="person">
        <div>
            <div class="kicker">
                The IT Guy
            </div>
            <h1>
                Joshua Ebod
            </h1>
            <p class="about">  
                Every feature starts with code. From the smallest button to the biggest function, I'm the one making it happen.
            </p>
        </div>

        <div class="hero">
            <img src="<?= base_url('ebod.png') ?>" alt="joshua ebod">
        </div>
    </section>

    <section class="project">

        <img src="<?= base_url('movie.png') ?>" alt="Movie Project">
        
        <div class="project-body">
            <div class="kicker">
                Project
            </div>
            <h2>
                Movie Discovery Platform
            </h2>
            <p>
                A movie discovery platform that allows users to search for movies, view details, and discover new films. Built with a focus on user experience and performance.
            </p>
        </div>
    </section>

    <footer>
        <span>© 2026</span>
        <span>Ebod</span>
    </footer>

    </div>

</body>
</html>